<?php $__env->startSection('title', 'Conversas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> RELACIONAMENTO</div>
    <div class="page-title-row"><div><h1>Conversas</h1><p>Histórico compartilhado dos canais simulados e preferência de novidades.</p></div></div>
    <div class="admin-demo-banner"><span>♡</span><p><strong>Privacidade em primeiro lugar.</strong> As conversas são demonstrativas e não incluem nome ou contato. Só conversas com consentimento registrado poderiam receber novidades; nenhum envio está conectado.</p></div>
    <section class="admin-panel list-panel">
        <div class="conversation-filters" aria-label="Filtrar conversas">
            <a class="<?php echo e($consentFilter === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('admin.conversations.index')); ?>">Todas</a>
            <a class="<?php echo e($consentFilter === 'yes' ? 'active' : ''); ?>" href="<?php echo e(route('admin.conversations.index', ['consent' => 'yes'])); ?>">Aceitaram novidades</a>
            <a class="<?php echo e($consentFilter === 'no' ? 'active' : ''); ?>" href="<?php echo e(route('admin.conversations.index', ['consent' => 'no'])); ?>">Sem consentimento</a>
        </div>
        <?php if($conversations->isEmpty()): ?>
            <div class="empty-state"><span>♡</span><strong>Nenhuma conversa neste filtro</strong><small>Quando alguém usar o chat, o histórico aparecerá aqui.</small></div>
        <?php else: ?>
            <div class="table-scroll"><table class="admin-table conversation-table"><thead><tr><th>Referência</th><th>Canal recente</th><th>Mensagens</th><th>Orçamentos</th><th>Novidades</th><th>Atividade</th><th></th></tr></thead><tbody>
                <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><span class="quote-reference"><?php echo e(substr($conversation->public_id, 0, 8)); ?></span></td><td><?php echo e(ucfirst($conversation->channel)); ?></td><td><?php echo e($conversation->messages_count); ?></td><td><?php echo e($conversation->quotes_count); ?></td><td><span class="consent-pill <?php echo e($conversation->marketing_consent ? 'consent-yes' : 'consent-no'); ?>"><?php echo e($conversation->marketing_consent ? 'Aceitou' : 'Não aceitou'); ?></span></td><td><?php echo e($conversation->last_message_at?->format('d/m/Y H:i') ?? '—'); ?></td><td><a class="row-actions" href="<?php echo e(route('admin.conversations.show', $conversation)); ?>">Ver histórico →</a></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
            <div class="pagination-wrap"><?php echo e($conversations->links()); ?></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/conversations/index.blade.php ENDPATH**/ ?>