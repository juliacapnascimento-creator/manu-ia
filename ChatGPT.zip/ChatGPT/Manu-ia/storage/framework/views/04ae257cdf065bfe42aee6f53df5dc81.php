<?php $__env->startSection('title', $product->exists ? 'Editar produto' : 'Novo produto'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> CATÁLOGO / <?php echo e($product->exists ? 'EDITAR' : 'NOVO PRODUTO'); ?></div>
    <div class="page-title-row"><div><h1><?php echo e($product->exists ? 'Editar produto' : 'Novo produto'); ?></h1><p>O agente usa estes dados nas respostas e nos orçamentos.</p></div><a class="admin-back-link" href="<?php echo e(route('admin.products.index')); ?>">← voltar ao catálogo</a></div>
    <form class="admin-panel product-edit-form" method="POST" action="<?php echo e($product->exists ? route('admin.products.update', $product) : route('admin.products.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($product->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <div class="form-section-heading"><span>01</span><div><h2>Informações da peça</h2><p>Preencha apenas o que foi confirmado.</p></div></div>
        <div class="admin-form-grid">
            <div class="admin-field"><label for="name">Nome do produto <b>*</b></label><input id="name" name="name" value="<?php echo e(old('name', $product->name)); ?>" maxlength="120" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="species">Espécie representada</label><input id="species" name="species" value="<?php echo e(old('species', $product->species)); ?>" maxlength="120" placeholder="Ex.: mico-leão-dourado"><?php $__errorArgs = ['species'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="category">Categoria <b>*</b></label><input id="category" name="category" value="<?php echo e(old('category', $product->category)); ?>" maxlength="120" placeholder="Ex.: Fauna da Mata Atlântica" required><?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="availability">Disponibilidade cadastrada <b>*</b></label><select id="availability" name="availability" required><?php $__currentLoopData = ['available' => 'Disponível', 'made_to_order' => 'Por encomenda', 'out_of_stock' => 'Indisponível']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(old('availability', $product->availability ?: 'available') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['availability'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field full-field"><label for="description">Descrição <b>*</b></label><textarea id="description" name="description" rows="3" maxlength="2000" required><?php echo e(old('description', $product->description)); ?></textarea><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="illustration">Ilustração usada no site <b>*</b></label><select id="illustration" name="illustration" required><?php $__currentLoopData = ['mico' => 'Mico', 'tucano' => 'Tucano', 'preguica' => 'Preguiça', 'bromelia' => 'Bromélia']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(old('illustration', $product->illustration ?: 'mico') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['illustration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        </div>
        <div class="form-section-heading form-section-next"><span>02</span><div><h2>Preços em reais (R$)</h2><p>Valores vazios serão tratados como “a consultar”.</p></div></div>
        <div class="admin-form-grid price-grid">
            <div class="admin-field"><label for="price">Preço por unidade</label><div class="input-prefix"><span>R$</span><input id="price" name="price" type="number" min="0" max="9999999.99" step="0.01" value="<?php echo e(old('price', $product->price)); ?>" placeholder="deixe vazio para consultar"></div><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="personalization_price">Adicional de personalização por unidade</label><div class="input-prefix"><span>R$</span><input id="personalization_price" name="personalization_price" type="number" min="0" max="9999999.99" step="0.01" value="<?php echo e(old('personalization_price', $product->personalization_price)); ?>" placeholder="deixe vazio para consultar"></div><?php $__errorArgs = ['personalization_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        </div>
        <div class="form-section-heading form-section-next"><span>03</span><div><h2>Revisão do cadastro</h2><p>Marque como revisado somente após confirmação com a empresa.</p></div></div>
        <div class="admin-checkboxes">
            <input type="hidden" name="is_demo" value="0"><label><input type="checkbox" name="is_demo" value="1" <?php if((bool) old('is_demo', $product->exists ? $product->is_demo : true)): echo 'checked'; endif; ?>><span><strong>Dados demonstrativos</strong><small>Use para nomes, descrições, preços e taxas fictícios.</small></span></label>
            <input type="hidden" name="is_active" value="0"><label><input type="checkbox" name="is_active" value="1" <?php if((bool) old('is_active', $product->exists ? $product->is_active : true)): echo 'checked'; endif; ?>><span><strong>Produto ativo</strong><small>Produtos ativos aparecem no site e no simulador de orçamento.</small></span></label>
        </div>
        <?php if($errors->any()): ?><div class="form-errors"><strong>Revise os campos sinalizados antes de salvar.</strong></div><?php endif; ?>
        <div class="form-actions"><a class="admin-secondary-link" href="<?php echo e(route('admin.products.index')); ?>">Cancelar</a><button class="admin-primary-link" type="submit"><?php echo e($product->exists ? 'Salvar alterações' : 'Cadastrar produto'); ?> <span>↗</span></button></div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/products/form.blade.php ENDPATH**/ ?>