<?php $__env->startSection('title', 'Catálogo'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> PRODUTOS</div>
    <div class="page-title-row"><div><h1>Catálogo</h1><p>Atualize o que a Manu pode apresentar e usar nos cálculos.</p></div><a class="admin-primary-link" href="<?php echo e(route('admin.products.create')); ?>">+ Novo produto</a></div>
    <div class="admin-demo-banner"><span>✳</span><p>Itens com selo <strong>A CONFIRMAR</strong> usam dados das imagens enviadas. Confirme preço e disponibilidade atualizados antes de marcar como revisados.</p></div>
    <section class="admin-panel list-panel"><div class="panel-heading"><div><h2>Produtos cadastrados</h2><p><?php echo e($products->where('is_active', true)->count()); ?> ativos · <?php echo e($products->count()); ?> no total</p></div></div>
        <?php if($products->isEmpty()): ?><div class="empty-state"><span>✿</span><strong>O catálogo está vazio</strong><small>Cadastre um produto para exibi-lo no protótipo.</small></div>
        <?php else: ?>
            <div class="table-scroll"><table class="admin-table product-table"><thead><tr><th>Produto</th><th>Preço-base</th><th>Personalização</th><th>Disponibilidade</th><th>Dados</th><th></th></tr></thead><tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($product->is_active ? '' : 'row-inactive'); ?>"><td><div class="table-product-name"><span class="product-spot spot-<?php echo e($product->illustration); ?>">✿</span><span><strong><?php echo e($product->name); ?></strong><small><?php echo e($product->species ?? $product->category); ?></small></span></div></td><td><?php echo e($product->price !== null ? 'R$ '.number_format((float) $product->price, 2, ',', '.') : 'A consultar'); ?></td><td><?php echo e($product->personalization_price !== null ? '+ R$ '.number_format((float) $product->personalization_price, 2, ',', '.') : 'A consultar'); ?></td><td><?php echo e(['unknown' => 'A confirmar', 'available' => 'Disponível', 'made_to_order' => 'Por encomenda', 'out_of_stock' => 'Indisponível'][$product->availability] ?? $product->availability); ?></td><td><span class="status-pill <?php echo e($product->is_demo ? 'status-pending' : 'status-converted'); ?>"><?php echo e($product->is_demo ? 'A confirmar' : 'Revisado'); ?></span><?php if (! ($product->is_active)): ?><small class="inactive-label">Arquivado</small><?php endif; ?></td><td><div class="row-actions"><a href="<?php echo e(route('admin.products.edit', $product)); ?>">Editar</a><?php if($product->is_active): ?><form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="archive-button">Arquivar</button></form><?php endif; ?></div></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/products/index.blade.php ENDPATH**/ ?>