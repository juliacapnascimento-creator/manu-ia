<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Entrar no painel · Manu IA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
</head>
<body class="login-body">
    <div class="login-wrap">
        <a class="admin-brand login-brand" href="<?php echo e(route('home')); ?>"><span class="admin-brand-mark">m</span><span><strong>manu<span>pekena</span></strong><small>PAINEL MANU IA</small></span></a>
        <section class="login-card"><div class="login-eyebrow"><span></span> ÁREA DA EQUIPE</div><h1>Boas-vindas<br>de <em>volta.</em></h1><p>Entre para acompanhar o catálogo e os orçamentos demonstrativos.</p>
            <form method="POST" action="<?php echo e(route('admin.login.store')); ?>">
                <?php echo csrf_field(); ?>
                <label for="email">E-mail</label><input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="password">Senha</label><input id="password" name="password" type="password" autocomplete="current-password" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="login-button" type="submit">Entrar no painel <span>↗</span></button>
            </form>
            <div class="login-note"><span>♧</span> Sem uma conta de equipe? Crie a primeira pelo terminal com <code>php artisan admin:create-user</code>.</div>
        </section>
        <a class="login-back" href="<?php echo e(route('home')); ?>">← voltar ao protótipo do site</a>
    </div>
</body>
</html>
<?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/login.blade.php ENDPATH**/ ?>