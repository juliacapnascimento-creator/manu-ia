<?php $__env->startSection('title', 'Visão geral'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> <?php echo e(now()->locale('pt_BR')->translatedFormat('l, d \d\e F')); ?></div>
    <div class="page-title-row"><div><h1>Visão geral</h1><p>Acompanhe a atividade do protótipo Manu IA.</p></div><a class="admin-primary-link" href="<?php echo e(route('admin.products.create')); ?>">+ Cadastrar produto</a></div>
    <div class="admin-demo-banner"><span>✳</span><p><strong>Indicadores deste protótipo.</strong> Orçamentos convertidos são status marcados manualmente e não confirmam vendas; compras ainda não são registradas. Nenhuma campanha ou mensagem automática está ativa.</p></div>
    <section class="metric-grid">
        <article class="metric-card metric-sage"><div class="metric-top"><span>Orçamentos enviados</span><span class="metric-icon">▤</span></div><strong><?php echo e($totalQuotes); ?></strong><small>Total de simulações recebidas</small></article>
        <article class="metric-card metric-clay"><div class="metric-top"><span>Orçamentos pendentes</span><span class="metric-icon">▤</span></div><strong><?php echo e($pendingQuotes); ?></strong><small>Simulações aguardando análise</small></article>
        <article class="metric-card metric-blue"><div class="metric-top"><span>Conversas</span><span class="metric-icon">♡</span></div><strong><?php echo e($conversations); ?></strong><small><?php echo e($consentedConversations); ?> com preferência de novidades</small></article>
        <article class="metric-card metric-cream"><div class="metric-top"><span>Conversões registradas</span><span class="metric-icon">↗</span></div><strong><?php echo e($convertedQuotes); ?></strong><small>Marcadas manualmente pela equipe</small></article>
    </section>
    <section class="admin-panel recent-panel"><div class="panel-heading"><div><h2>Orçamentos recentes</h2><p>As alterações aqui não enviam mensagens.</p></div><a href="<?php echo e(route('admin.quotes.index')); ?>">Ver todos <span>→</span></a></div>
        <?php if($recentQuotes->isEmpty()): ?><div class="empty-state"><span>▤</span><strong>Nenhuma simulação por enquanto</strong><small>Quando alguém enviar um orçamento pelo site, ele aparecerá aqui.</small></div>
        <?php else: ?>
            <div class="table-scroll"><table class="admin-table"><thead><tr><th>Referência</th><th>Peça</th><th>Quantidade</th><th>Data</th><th>Situação</th></tr></thead><tbody>
                <?php $__currentLoopData = $recentQuotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><span class="quote-reference">#<?php echo e(substr($quote->public_id, 0, 8)); ?></span><?php if($quote->is_demo): ?><span class="table-demo-tag">DEMO</span><?php endif; ?></td><td><?php echo e($quote->product->name); ?></td><td><?php echo e($quote->quantity); ?></td><td><?php echo e($quote->created_at->format('d/m/Y')); ?></td><td><span class="status-pill status-<?php echo e($quote->status); ?>"><?php echo e(ucfirst($quote->status)); ?></span></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
        <?php endif; ?>
    </section>
    <section class="admin-help"><div class="help-icon">✳</div><div><strong>Cadastre somente informações confirmadas</strong><p>Use o selo “dados revisados” apenas depois da ManuPekena validar preço, descrição e disponibilidade.</p></div><a href="<?php echo e(route('admin.products.index')); ?>">Abrir catálogo →</a></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>