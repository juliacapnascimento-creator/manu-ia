<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Painel'); ?> · Manu IA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-crm.css')); ?>">
</head>
<body class="admin-body">
    <header class="admin-topbar">
        <a class="admin-brand" href="<?php echo e(route('admin.dashboard')); ?>"><span class="admin-brand-mark">m</span><span><strong>manu<span>pekena</span></strong><small>PAINEL MANU IA</small></span></a>
        <div class="admin-top-right"><span class="prototype-badge"><i></i> protótipo</span><a href="<?php echo e(route('home')); ?>">Ver site <span>↗</span></a><span class="admin-user"><?php echo e(auth()->user()->name); ?></span><form method="POST" action="<?php echo e(route('admin.logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="logout-button">Sair</button></form></div>
    </header>
    <div class="admin-shell">
        <aside class="admin-sidebar">
            <span class="sidebar-label">ESPAÇO DE TRABALHO</span>
            <a class="sidebar-link <?php echo e(request()->routeIs('admin.dashboard') ? 'selected' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>"><span>⌂</span> Visão geral</a>
            <a class="sidebar-link <?php echo e(request()->routeIs('admin.products.*') ? 'selected' : ''); ?>" href="<?php echo e(route('admin.products.index')); ?>"><span>✿</span> Catálogo</a>
            <a class="sidebar-link <?php echo e(request()->routeIs('admin.conversations.*') ? 'selected' : ''); ?>" href="<?php echo e(route('admin.conversations.index')); ?>"><span>♡</span> Conversas</a>
            <a class="sidebar-link <?php echo e(request()->routeIs('admin.quotes.*') ? 'selected' : ''); ?>" href="<?php echo e(route('admin.quotes.index')); ?>"><span>▤</span> Orçamentos</a>
            <div class="sidebar-note"><span>✳</span><p>Confirme os dados com a ManuPekena antes de marcá-los como revisados.</p></div>
            <div class="sidebar-bottom"><span>AMBIENTE</span><strong>DEMONSTRAÇÃO</strong></div>
        </aside>
        <main class="admin-main">
            <div class="admin-content">
                <?php if(session('status')): ?><div class="admin-flash" role="status"><span>✓</span><?php echo e(session('status')); ?></div><?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <footer class="admin-footer">Manu IA · painel demonstrativo · ações do painel não enviam mensagens para clientes</footer>
        </main>
    </div>
</body>
</html>
<?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/layout.blade.php ENDPATH**/ ?>