<?php $__env->startSection('title', 'Orçamentos'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> RELACIONAMENTO / ORÇAMENTOS</div>
    <div class="page-title-row"><div><h1>Orçamentos</h1><p>Acompanhe as simulações salvas pelo site e atualize a situação.</p></div></div>
    <div class="admin-demo-banner"><span>✳</span><p>Atualizar a situação é apenas um registro interno. Nenhuma notificação ou mensagem é enviada ao cliente.</p></div>
    <section class="admin-panel list-panel"><div class="panel-heading"><div><h2>Simulações recentes</h2><p>Exibindo até 100 registros mais recentes.</p></div></div>
        <?php if($quotes->isEmpty()): ?><div class="empty-state"><span>▤</span><strong>Nenhum orçamento ainda</strong><small>As simulações enviadas pelo site aparecerão nesta lista.</small></div>
        <?php else: ?>
            <div class="table-scroll"><table class="admin-table quote-table"><thead><tr><th>Referência</th><th>Peça</th><th>Qtd.</th><th>Personalização</th><th>Total</th><th>Finalidade</th><th>Data</th><th>Situação</th><th></th></tr></thead><tbody>
                <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><span class="quote-reference">#<?php echo e(substr($quote->public_id, 0, 8)); ?></span><?php if($quote->is_demo): ?><span class="table-demo-tag">DEMO</span><?php endif; ?></td><td><?php echo e($quote->product->name); ?></td><td><?php echo e($quote->quantity); ?></td><td><?php echo e($quote->customization ? 'Sim' : 'Não'); ?></td><td class="quote-total-cell">R$ <?php echo e(number_format((float) $quote->total, 2, ',', '.')); ?></td><td><?php echo e(ucfirst($quote->purpose)); ?></td><td><?php echo e($quote->created_at->format('d/m/Y')); ?></td><td><span class="status-pill status-<?php echo e($quote->status); ?>"><?php echo e(['pending' => 'Pendente', 'approved' => 'Em análise', 'converted' => 'Convertido', 'abandoned' => 'Encerrado'][$quote->status] ?? $quote->status); ?></span></td><td><form class="status-form" method="POST" action="<?php echo e(route('admin.quotes.status', $quote)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><label class="sr-only" for="quote-status-<?php echo e($quote->id); ?>">Atualizar situação</label><select id="quote-status-<?php echo e($quote->id); ?>" name="status" aria-label="Atualizar situação para orçamento #<?php echo e(substr($quote->public_id, 0, 8)); ?>"><?php $__currentLoopData = ['pending' => 'Pendente', 'approved' => 'Em análise', 'converted' => 'Convertido', 'abandoned' => 'Encerrado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if($quote->status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><button type="submit" title="Salvar situação">✓</button></form></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/quotes/index.blade.php ENDPATH**/ ?>