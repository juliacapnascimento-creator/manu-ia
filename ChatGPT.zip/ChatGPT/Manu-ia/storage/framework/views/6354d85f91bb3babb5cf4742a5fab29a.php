<?php $__env->startSection('title', 'Histórico de conversa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-kicker"><span></span> RELACIONAMENTO</div>
    <div class="page-title-row"><div><h1>Histórico</h1><p>Conversa <?php echo e(substr($conversation->public_id, 0, 8)); ?> · atividade <?php echo e($conversation->last_message_at?->format('d/m/Y H:i') ?? 'não registrada'); ?></p></div><a class="admin-back-link" href="<?php echo e(route('admin.conversations.index')); ?>">← Todas as conversas</a></div>
    <div class="admin-demo-banner"><span>♡</span><p>Preferência de novidades: <strong><?php echo e($conversation->marketing_consent ? 'aceita' : 'não aceita'); ?></strong>. Para este protótipo, nenhuma comunicação externa é enviada.</p></div>
    <section class="admin-panel transcript-panel"><div class="panel-heading"><div><h2>Mensagens</h2><p>Conteúdo fornecido no chat demonstrativo.</p></div></div>
        <?php $__empty_1 = true; $__currentLoopData = $conversation->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="transcript-message <?php echo e($message->role === 'assistant' ? 'assistant-message' : 'visitor-message'); ?>"><div><strong><?php echo e($message->role === 'assistant' ? 'Manu IA' : 'Visitante'); ?></strong><small><?php echo e(ucfirst($message->channel)); ?> · <?php echo e($message->created_at->format('d/m/Y H:i')); ?></small></div><p><?php echo e($message->content); ?></p></article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state"><strong>Esta conversa ainda não tem mensagens</strong></div>
        <?php endif; ?>
    </section>
    <section class="admin-panel list-panel conversation-quotes"><div class="panel-heading"><div><h2>Orçamentos ligados</h2><p>Simulações associadas a esta conversa.</p></div></div>
        <?php $__empty_1 = true; $__currentLoopData = $conversation->quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="linked-quote"><span>#<?php echo e(substr($quote->public_id, 0, 8)); ?> <?php if($quote->is_demo): ?><small>DEMO</small><?php endif; ?></span><strong><?php echo e($quote->product->name); ?> · <?php echo e($quote->quantity); ?> un.</strong><strong>R$ <?php echo e(number_format((float) $quote->total, 2, ',', '.')); ?></strong><span class="status-pill status-<?php echo e($quote->status); ?>"><?php echo e(ucfirst($quote->status)); ?></span></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state"><strong>Sem orçamentos associados</strong></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/julianascimento/Documents/ChatGPT/Manu-ia/resources/views/admin/conversations/show.blade.php ENDPATH**/ ?>